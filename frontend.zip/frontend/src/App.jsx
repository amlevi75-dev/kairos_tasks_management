import { useState, useEffect, createContext, useContext } from "react";
import LoginPage    from "./views/LoginPage";
import Dashboard    from "./views/Dashboard";
import ProjectView  from "./views/ProjectView";
import MyTasks      from "./views/MyTasks";
import AdminUsers   from "./views/AdminUsers";
import ProjectUsers   from "./views/ProjectUsers";
import ProjectAnalytics from "./views/ProjectAnalytics";
import Layout       from "./components/Layout";

export const AuthContext     = createContext(null);
export const BrandingContext = createContext({ app_name:"Kairos", logo_letter:"K", primary_color:"#0F766E", logo_svg:"/kairos-icon.svg" });

export const useAuth     = () => useContext(AuthContext);
export const useBranding = () => useContext(BrandingContext);

// Use relative URL when served by FastAPI; fallback to localhost for dev
const API = window.location.port === "5173" ? "http://localhost:8000/api" : "/api";

// Display dates as dd-mm-yyyy everywhere in the UI. Storage, the API, and
// every <input type="date"> stay ISO (yyyy-mm-dd) — that format is fixed by
// the HTML date input spec and can't be changed; this only affects how a
// date is shown as plain text.
// Hebrew (U+0590-05FF) or Arabic (U+0600-06FF) anywhere in the text switches
// that field to RTL. Free-text fields (description, comments) can legitimately
// be typed in either direction depending on who's writing, unlike the rest of
// the app's chrome, which stays LTR — see index.css.
export function isRTL(text) {
  if (!text) return false;
  return /[\u0590-\u05FF\u0600-\u06FF]/.test(text);
}

// Minimal markdown for comments: **bold**, *italic*, and "1. item" numbered
// lines. Deliberately not a real markdown parser (no nesting, no links,
// no code blocks) — comments compose this with @mention highlighting
// (see parseCommentBody below), so keeping the grammar tiny keeps the two
// concerns from colliding, e.g. "*" inside a mention or "1." at a line
// start that isn't meant as a list.
//
// Returns an array of React nodes for one line's worth of text (no
// newlines) — callers that also need @mention highlighting should run
// splitMentions() first and pass this over each non-mention chunk.
export function renderInlineMarkdown(text, keyPrefix = "") {
  if (!text) return [text];
  const parts = String(text).split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**") && part.length > 4) {
      return <strong key={`${keyPrefix}b${i}`}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("*") && part.endsWith("*") && part.length > 2) {
      return <em key={`${keyPrefix}i${i}`}>{part.slice(1, -1)}</em>;
    }
    return part;
  });
}

// Splits a full comment body into lines, rendering **bold**/*italic* per
// line and grouping consecutive "N. " lines into a real <ol> so a typed
// numbered list actually looks like one instead of literal "1. " text.
export function renderCommentMarkdown(text, mentionRenderer) {
  if (!text) return null;
  const lines = String(text).split("\n");
  const blocks = [];
  let listItems = null;

  const renderLine = (line, key) => {
    // @mention highlighting runs first (it already exists and works well);
    // markdown is applied inside each non-mention chunk it produces.
    const chunks = mentionRenderer ? mentionRenderer(line, key) : [line];
    return chunks.flatMap((chunk, ci) =>
      typeof chunk === "string"
        ? renderInlineMarkdown(chunk, `${key}-${ci}-`)
        : [chunk]
    );
  };

  lines.forEach((line, idx) => {
    const m = line.match(/^\d+\.\s+(.*)$/);
    if (m) {
      if (!listItems) listItems = [];
      listItems.push(<li key={`li${idx}`}>{renderLine(m[1], `l${idx}`)}</li>);
      return;
    }
    if (listItems) {
      blocks.push(<ol key={`ol${idx}`} style={{ margin: "4px 0", paddingInlineStart: 20 }}>{listItems}</ol>);
      listItems = null;
    }
    blocks.push(
      <span key={`ln${idx}`}>
        {renderLine(line, `p${idx}`)}
        {idx < lines.length - 1 && <br />}
      </span>
    );
  });
  if (listItems) {
    blocks.push(<ol key="ol-end" style={{ margin: "4px 0", paddingInlineStart: 20 }}>{listItems}</ol>);
  }
  return blocks;
}

export function fmtDate(iso) {
  if (!iso) return "";
  const datePart = String(iso).slice(0, 10);          // strips any time part
  const m = datePart.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return datePart;                              // not ISO — show as-is
  const [, y, mo, d] = m;
  return `${d}-${mo}-${y}`;
}

// Same, but keeps the HH:MM that several places append after slice(0,16).
export function fmtDateTime(iso) {
  if (!iso) return "";
  const s = String(iso);
  const datePart = fmtDate(s.slice(0, 10));
  const timePart = s.slice(11, 16);                      // "HH:MM" if present
  return timePart ? `${datePart} ${timePart}` : datePart;
}

export function apiFetch(path, options = {}) {
  return fetch(`${API}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  }).then(async (res) => {
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || "Request failed");
    }
    return res.json();
  });
}

export default function App() {
  // lang/dir are set once in main.jsx (UI_LANG).

  const [user, setUser]         = useState(undefined);
  const [branding, setBranding] = useState({ app_name:"TaskMaster", logo_letter:"T", primary_color:"#3b82f6" });
  const [page, setPage]         = useState({ name:"dashboard", params:{} });

  useEffect(() => {
    // Load branding first (no auth needed)
    apiFetch("/branding").then(setBranding).catch(() => {});
    // Then check session
    apiFetch("/auth/me").then(d => setUser(d.user)).catch(() => setUser(null));
  }, []);

  // Update page title from branding
  useEffect(() => {
    document.title = branding.app_name;
  }, [branding.app_name]);

  if (user === undefined) {
    return (
      <BrandingContext.Provider value={branding}>
        <div style={{ display:"flex", height:"100vh", alignItems:"center", justifyContent:"center", background:"#0f172a" }}>
          <div style={{ color:"var(--text-muted)", fontSize:14 }}>Loading {branding.app_name}…</div>
        </div>
      </BrandingContext.Provider>
    );
  }

  if (!user) {
    return (
      <BrandingContext.Provider value={branding}>
        <AuthContext.Provider value={{ user, setUser }}>
          <LoginPage onLogin={(u) => { setUser(u); setPage({ name:"dashboard", params:{} }); }} />
        </AuthContext.Provider>
      </BrandingContext.Provider>
    );
  }

  const renderPage = () => {
    switch (page.name) {
      case "project":       return <ProjectView  projectId={page.params.projectId} navigate={setPage} />;
      case "project-users":    return <ProjectUsers    projectId={page.params.projectId} navigate={setPage} />;
      case "project-analytics": return <ProjectAnalytics projectId={page.params.projectId} navigate={setPage} />;
      case "mytasks":       return <MyTasks navigate={setPage} />;
      case "admin-users":   return <AdminUsers />;
      default:              return <Dashboard navigate={setPage} />;
    }
  };

  return (
    <BrandingContext.Provider value={branding}>
      <AuthContext.Provider value={{ user, setUser }}>
        <Layout navigate={setPage} currentPage={page.name} currentParams={page.params}>
          {renderPage()}
        </Layout>
      </AuthContext.Provider>
    </BrandingContext.Provider>
  );
}
