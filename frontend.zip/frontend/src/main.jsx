import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";

// Interface language and direction — set once, before the first render, so a
// Windows Hebrew locale or Hebrew AD names can't flip the page on their own.
// The UI strings are English today. Every layout uses logical (inline-start/
// end) properties, so once Hebrew strings exist, setting UI_LANG = "he" here
// mirrors the whole app with no per-component changes.
const UI_LANG = "en";
const RTL_LANGS = ["he", "ar"];
document.documentElement.setAttribute("lang", UI_LANG);
document.documentElement.setAttribute("dir", RTL_LANGS.includes(UI_LANG) ? "rtl" : "ltr");

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
